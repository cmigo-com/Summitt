# Summit Trails — Hiking Destination Research & Catalogue Plan

## Purpose

This document converts the client-supplied Tripadvisor research into an original Summit Trails destination catalogue. Tripadvisor material is treated as background research only. No traveler reviews, Tripadvisor marketing sentences, Tripadvisor photos or Tripadvisor prices are used as Summit Trails public content.

## Publication rule

- `active=true` means visible/bookable in the customer catalogue.
- `ready_for_catalogue=true` means there is enough destination-level information to structure a record, but it does **not** mean the adventure is ready to sell.
- Missing commercial values remain `Needs verification` or `Needs Summit Trails pricing`.
- Summit Trails Admin controls prices, departure dates, slots, featured status and active status.
- Existing confirmed bookings keep their stored adult/child unit prices and total; later price edits do not recalculate them.

## Current verification outcome

### Existing Summit Trails products retained as active
1. Mount Kenya — Point Lenana via Sirimon–Chogoria
2. Mount Longonot — Crater Rim Circuit

Their original Summit Trails adult prices and existing departure dates are retained. Child prices are not invented and therefore remain unset until Summit Trails provides them.

### Destination records structured for future verification/publication
- Karura Forest
- Ngong Hills
- Mount Satima
- Torok Waterfalls
- Ragia Falls
- Seven Ponds / Table Mountain
- Njine Kabia Falls
- Chagaik Arboretum
- Mt Kilimambogo
- Aberdare Hiking Adventure / Aberdare Forest
- Hell's Gate National Park
- Ndere Island National Park
- Maragoli Hills
- Menengai Crater
- Mount Lesatima & Dragon Teeth
- Mount Elgon
- Kakamega Forest
- Lake Elementaita

These records are seeded as inactive unless already an existing Summit Trails product. Admin must verify route, access, permits/ranger requirements, fees, meeting points, current opening arrangements, Summit Trails prices and departure dates before activating them.

### Research leads that should remain unpublished for now
- Oloolua Nature Trail
- Bamburi Nature Trail
- Boito Waterfalls
- Sigiria Nature Trail
- Oloolua Trails (duplicate/alternate naming)
- Mona Trails (operator/source, not a single destination)
- Oloololo Escarpment
- Nguruman Escarpment
- Ol Doinyo Eburru
- Nancy Beth Bird Sanctuary
- Karura Forest Trails (duplicate/alternate naming)

## Verified/current source themes

### Kenya Wildlife Service
Current KWS material confirms Mount Kenya as a high-altitude national park with Batian, Nelion and Point Lenana; KWS lists official access gates and current visitor/safety guidance. KWS also currently publishes destination information for Mount Longonot, Hell's Gate, Mount Elgon, Ndere Island, Kakamega Forest and Lake Elementaita.

### Kenya Forest Service
KFS confirms Karura Forest as a large urban gazetted forest with marked walking trails, waterfalls, Mau Mau caves, bird and butterfly life and forest-walking activities. KFS also lists forest stations relevant to Ngong Hills, Maragoli Hills, Eburru and the Aberdare forest system.

### National Tourism Service Portal
The official tourism portal identifies Mount Kenya, Aberdare, Hell's Gate, Karura, Ngong Hills, Kakamega and other nature destinations as part of Kenya's nature/adventure tourism offer. It is used for destination-level context, not for Summit Trails pricing.

## Items requiring explicit verification before activation

1. Current entry/park fees for the exact traveler category.
2. Current opening and closing arrangements.
3. Whether a guide/ranger is mandatory for the exact route.
4. Exact trailhead and meeting point.
5. Current route distance and elevation where secondary sources disagree.
6. Seasonal access, road conditions and weather restrictions.
7. Wildlife exposure and applicable safety protocols.
8. Summit Trails adult and child package prices.
9. Summit Trails inclusions/exclusions.
10. Summit Trails departure dates and maximum slots.
11. Summit Trails-owned/authorized photographs.

## Original public-content approach

Public descriptions are written specifically for Summit Trails. They describe the landscape, terrain and experience without presenting research-source reviews as customer feedback. No testimonials are generated from research.

## Source register

- Kenya Wildlife Service — Mount Kenya National Park
- Kenya Wildlife Service — Mount Longonot National Park
- Kenya Wildlife Service — Hell's Gate National Park
- Kenya Wildlife Service — Mount Elgon National Park
- Kenya Wildlife Service — Ndere Island National Park
- Kenya Wildlife Service — Kakamega Forest National Reserve
- Kenya Wildlife Service — Lake Elementaita Wildlife Sanctuary
- Kenya Forest Service — Karura Forest
- Kenya Forest Service — Our Forests / Conservancies
- National Tourism Service Portal — Eco-Tourism, Nature & Scenic Tourism
- National Tourism Service Portal — Central Kenya Circuit
- Current secondary/local sources were used only to identify research leads such as Ragia Falls, Torok Waterfalls, Njine Kabia Falls and Aberdare moorland routes. Their commercial details remain unverified in Summit Trails.

## Database implementation

`database/destination_catalogue.json` contains the structured research catalogue.

`database/seed_destination_catalogue.sql` seeds research-ready destinations as inactive so they can be reviewed in Admin before publication.

`database/schema.sql` adds:
- category, county, terrain and elevation fields
- original destination descriptions and highlights
- suitability and trip-format data
- what-to-bring and safety fields
- park/guide/opening-hours verification fields
- editable adult and child prices
- currency, discount and price status
- gallery image placeholders
- featured and active flags
- verification/source notes
- booking adult/child counts and price snapshots

## Booking pricing rule

For a new booking:

`Adult Price × Adults + Child Price × Children − Discount = Booking Total`

The adult/child unit prices and final total are stored on the booking record. Future admin price edits therefore do not alter an existing confirmed booking.
