const BRAND = {
  name: 'SUMMIT TRAILS',
  tagline: 'HIKING • TREKKING • MOUNTAIN ADVENTURES',
  phone: '0713177186',
  email: 'waltermichael357@gmail.com',
  location: 'Nanyuki, Kenya'
};

function escapeHtml(value='') {
  return String(value).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
}

function money(value) {
  return `KSh ${Number(value || 0).toLocaleString('en-KE')}`;
}

function emailLayout(content) {
  return `<!doctype html><html><body style="margin:0;background:#f5f2e9;font-family:Arial,Helvetica,sans-serif;color:#25382b;">
  <div style="max-width:680px;margin:24px auto;background:#fff;border:1px solid #e6dfcf;">
    <div style="background:#1f3d2b;color:#fff;padding:26px 28px;border-bottom:5px solid #c8912f;">
      <div style="font-family:Georgia,serif;font-size:25px;letter-spacing:1px;font-weight:700;">${BRAND.name}</div>
      <div style="font-size:11px;letter-spacing:1.6px;margin-top:5px;color:#ead8aa;">${BRAND.tagline}</div>
    </div>
    <div style="padding:30px 28px;line-height:1.65;">${content}</div>
    <div style="background:#f8f6f1;padding:20px 28px;border-top:1px solid #e6dfcf;font-size:13px;color:#536056;">
      <strong style="color:#1f3d2b;">${BRAND.name}</strong><br>${BRAND.location}<br>
      <a href="tel:+254${BRAND.phone.slice(1)}" style="color:#1f3d2b;">${BRAND.phone}</a> ·
      <a href="mailto:${BRAND.email}" style="color:#1f3d2b;">${BRAND.email}</a>
    </div>
  </div></body></html>`;
}

async function sendEmail({to, subject, html, replyTo}) {
  if (!process.env.RESEND_API_KEY || !to || !process.env.RESEND_FROM_EMAIL) {
    return { sent:false, reason:'email_not_configured' };
  }
  const payload = { from: process.env.RESEND_FROM_EMAIL, to:[to], subject, html };
  if (replyTo) payload.reply_to = replyTo;
  const response = await fetch('https://api.resend.com/emails', {
    method:'POST',
    headers:{Authorization:`Bearer ${process.env.RESEND_API_KEY}`,'Content-Type':'application/json'},
    body:JSON.stringify(payload)
  });
  if (!response.ok) {
    const detail = await response.text().catch(()=> '');
    throw new Error(`Email provider rejected the message (${response.status}). ${detail.slice(0,300)}`);
  }
  return { sent:true, provider:'resend' };
}

const templates = {
  welcome({name, dashboardUrl, passwordSetupUrl}) {
    return emailLayout(`<h1 style="font-family:Georgia,serif;color:#1f3d2b;">Welcome to Summit Trails, ${escapeHtml(name)}</h1><p>We’re delighted to have you join Summit Trails. Your account is ready for exploring guided hiking, trekking and mountain adventures across Kenya.</p><p><a href="${escapeHtml(dashboardUrl || '/') }" style="display:inline-block;background:#1f3d2b;color:#fff;text-decoration:none;padding:12px 18px;border-radius:4px;">Access My Dashboard</a></p>${passwordSetupUrl?`<p><a href="${escapeHtml(passwordSetupUrl)}" style="display:inline-block;background:#c8912f;color:#1f3d2b;text-decoration:none;padding:12px 18px;border-radius:4px;font-weight:700;">Create / Change Password</a></p>`:''}`);
  },
  bookingReceived({name,booking,adventure,departure}) {
    const balance = Number(booking.total_price)-Number(booking.amount_paid);
    return emailLayout(`<h1 style="font-family:Georgia,serif;color:#1f3d2b;">Booking Received</h1><p>Hello ${escapeHtml(name)}, we have received your Summit Trails booking request.</p><p><strong>Booking:</strong> ${escapeHtml(booking.booking_reference)}<br><strong>Adventure:</strong> ${escapeHtml(adventure.title)}<br><strong>Departure:</strong> ${escapeHtml(departure.start_date)}${departure.end_date && departure.end_date!==departure.start_date ? ` to ${escapeHtml(departure.end_date)}`:''}<br><strong>Adults:</strong> ${booking.adults} &nbsp; <strong>Children:</strong> ${booking.children}<br><strong>Total:</strong> ${money(booking.total_price)}<br><strong>Paid:</strong> ${money(booking.amount_paid)}<br><strong>Outstanding:</strong> ${money(balance)}<br><strong>Status:</strong> ${escapeHtml(booking.status)}</p><p>Your booking remains pending confirmation where Summit Trails approval or payment verification is still required.</p>`);
  },
  bookingConfirmed({name,booking,adventure,departure}) {
    const balance = Number(booking.total_price)-Number(booking.amount_paid);
    return emailLayout(`<h1 style="font-family:Georgia,serif;color:#1f3d2b;">Your Summit Trails Booking is Confirmed</h1><p>Hello ${escapeHtml(name)}, your adventure reservation has been confirmed.</p><p><strong>Booking:</strong> ${escapeHtml(booking.booking_reference)}<br><strong>Adventure:</strong> ${escapeHtml(adventure.title)}<br><strong>Route:</strong> ${escapeHtml(adventure.route || 'As listed in your booking')}<br><strong>Departure:</strong> ${escapeHtml(departure.start_date)}${departure.end_date && departure.end_date!==departure.start_date ? ` to ${escapeHtml(departure.end_date)}`:''}<br><strong>Adults:</strong> ${booking.adults} &nbsp; <strong>Children:</strong> ${booking.children}<br><strong>Total:</strong> ${money(booking.total_price)}<br><strong>Paid:</strong> ${money(booking.amount_paid)}<br><strong>Balance:</strong> ${money(balance)}<br><strong>Meeting point:</strong> ${escapeHtml(adventure.meeting_point || 'Please confirm with Summit Trails before departure.')}</p><p>Please prepare according to the adventure information on your booking and follow the latest instructions from our team.</p>`);
  },
  paymentReceived({name,booking,payment}) {
    const balance = Number(booking.total_price)-Number(booking.amount_paid);
    return emailLayout(`<h1 style="font-family:Georgia,serif;color:#1f3d2b;">Payment Received</h1><p>Hello ${escapeHtml(name)}, your payment has been recorded and verified by Summit Trails.</p><p><strong>Booking:</strong> ${escapeHtml(booking.booking_reference)}<br><strong>Payment amount:</strong> ${money(payment.amount)}<br><strong>Payment reference:</strong> ${escapeHtml(payment.transaction_reference || 'Verified payment')}<br><strong>Total paid so far:</strong> ${money(booking.amount_paid)}<br><strong>Remaining balance:</strong> ${money(balance)}<br><strong>Payment date:</strong> ${escapeHtml(payment.created_at || new Date().toISOString())}</p>`);
  },
  paymentReminder({name,booking}) {
    const balance = Number(booking.total_price)-Number(booking.amount_paid);
    return emailLayout(`<h1 style="font-family:Georgia,serif;color:#1f3d2b;">Summit Trails Payment Reminder</h1><p>Hello ${escapeHtml(name)}, this is a reminder that your booking has an outstanding balance.</p><p><strong>Booking:</strong> ${escapeHtml(booking.booking_reference)}<br><strong>Total:</strong> ${money(booking.total_price)}<br><strong>Paid:</strong> ${money(booking.amount_paid)}<br><strong>Outstanding:</strong> ${money(balance)}</p><p>Please contact Summit Trails if you need help arranging the remaining payment.</p>`);
  },
  statusUpdate({name,booking,status,note}) {
    return emailLayout(`<h1 style="font-family:Georgia,serif;color:#1f3d2b;">Booking Status Update</h1><p>Hello ${escapeHtml(name)}, the status of your Summit Trails booking has been updated.</p><p><strong>Booking:</strong> ${escapeHtml(booking.booking_reference)}<br><strong>Status:</strong> ${escapeHtml(status)}</p>${note ? `<p><strong>Note:</strong> ${escapeHtml(note)}</p>`:''}`);
  },
  customerMessageReply({name,reply,conversationId}) {
    return emailLayout(`<h1 style="font-family:Georgia,serif;color:#1f3d2b;">Reply from Summit Trails</h1><p>Hello ${escapeHtml(name)},</p><p>Thank you for contacting Summit Trails.</p><div style="padding:18px;background:#f8f6f1;border-left:4px solid #c8912f;white-space:pre-wrap;">${escapeHtml(reply)}</div><p style="margin-bottom:0;">Conversation ID: <strong>${escapeHtml(conversationId)}</strong></p>`);
  },
  customerMessageReceived({name,conversationId,replyUrl}) {
    return emailLayout(`<h1 style="font-family:Georgia,serif;color:#1f3d2b;">We Received Your Message</h1><p>Hello ${escapeHtml(name)}, thank you for contacting Summit Trails.</p><p>We have received your message and our team will get back to you shortly.</p><p><strong>Conversation ID:</strong> ${escapeHtml(conversationId)}</p>${replyUrl?`<p><a href="${escapeHtml(replyUrl)}" style="display:inline-block;background:#1f3d2b;color:#fff;text-decoration:none;padding:12px 18px;border-radius:4px;">Continue This Conversation</a></p>`:''}`);
  }
};

module.exports = { BRAND, escapeHtml, money, emailLayout, sendEmail, templates };
