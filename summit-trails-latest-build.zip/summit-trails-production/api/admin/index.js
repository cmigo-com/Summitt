const { requireAdmin, send } = require('../_lib/supabase');
const { sendEmail, templates } = require('../_lib/email');

const list = v => Array.isArray(v) ? v : String(v || '').split('\n').map(s=>s.trim()).filter(Boolean);
const clean = (v,max=10000) => String(v ?? '').trim().slice(0,max);

async function bookingContext(db, bookingId) {
  const {data,error}=await db.from('bookings').select('*, profiles(id,full_name,phone_number), adventures(*), departures(*), payments(*), travelers(*), booking_members(*)').eq('id',bookingId).single();
  if(error) throw error;
  const {data:authUser}=await db.auth.admin.getUserById(data.user_id);
  data.customer_email=authUser?.user?.email || '';
  return data;
}

module.exports=async(req,res)=>{
 try{
  const {db}=await requireAdmin(req);
  if(req.method==='GET'){
    const p=req.query||{};
    const search=clean(p.search,100);
    let bookingsQ=db.from('bookings').select('*, profiles(id,full_name,phone_number), adventures(title,mountain_name,route), departures(start_date,end_date), payments(*), travelers(*), booking_members(*)').order('created_at',{ascending:false});
    const {data:allBookings,error:bErr}=await bookingsQ; if(bErr)throw bErr;
    let bookings=allBookings||[];
    if(p.status) bookings=bookings.filter(b=>b.status===p.status);
    if(p.payment_status) bookings=bookings.filter(b=>Number(b.amount_paid)>=Number(b.total_price)?p.payment_status==='paid':p.payment_status==='outstanding');
    if(p.adventure_id) bookings=bookings.filter(b=>Number(b.adventure_id)===Number(p.adventure_id));
    if(p.travel_date) bookings=bookings.filter(b=>b.departures?.start_date===p.travel_date);
    if(search){const s=search.toLowerCase();bookings=bookings.filter(b=>[b.booking_reference,b.profiles?.full_name,b.profiles?.phone_number,b.adventures?.title,b.adventures?.mountain_name].some(v=>String(v||'').toLowerCase().includes(s)));}
    const [{data:adventures,error:aErr},{data:customers,error:cErr},{data:messages,error:mErr},{data:destinations,error:dErr},{data:safari_packages,error:sErr},{data:gallery,error:gErr},{data:achievements,error:achErr},{data:faqs,error:fErr},{data:settings,error:stErr}]=await Promise.all([
      db.from('adventures').select('*, departures(*)').order('featured',{ascending:false}).order('id'),
      db.from('profiles').select('id,full_name,phone_number,role,created_at').order('created_at',{ascending:false}),
      db.from('contact_messages').select('*, adventures(title), message_replies(*)').order('created_at',{ascending:false}),
      db.from('destinations').select('*').order('featured',{ascending:false}).order('name'),
      db.from('safari_packages').select('*, safari_departures(*)').order('featured',{ascending:false}).order('name'),
      db.from('gallery_images').select('*, adventures(title)').order('sort_order').order('created_at',{ascending:false}),
      db.from('achievements').select('*').order('sort_order').order('id'),
      db.from('faqs').select('*').order('sort_order').order('id'),
      db.from('site_settings').select('*')
    ]);
    if(aErr)throw aErr;if(cErr)throw cErr;if(mErr)throw mErr;if(dErr)throw dErr;if(sErr)throw sErr;if(gErr)throw gErr;if(achErr)throw achErr;if(fErr)throw fErr;if(stErr)throw stErr;
    const {data:authUsers}=await db.auth.admin.listUsers({page:1,perPage:1000});
    const emailById=new Map((authUsers?.users||[]).map(u=>[u.id,u.email]));
    const customersWithEmail=(customers||[]).map(c=>({...c,email:emailById.get(c.id)||''}));
    bookings.forEach(b=>{b.customer_email=emailById.get(b.user_id)||''});
    let filteredMessages=messages||[];
    if(p.message_status) filteredMessages=filteredMessages.filter(m=>m.status===p.message_status);
    if(p.message_search){const s=String(p.message_search).toLowerCase();filteredMessages=filteredMessages.filter(m=>[m.conversation_id,m.full_name,m.email,m.phone,m.subject,m.message].some(v=>String(v||'').toLowerCase().includes(s)));}
    return send(res,200,{bookings,adventures:adventures||[],customers:customersWithEmail,messages:filteredMessages,destinations:destinations||[],safari_packages:safari_packages||[],gallery:gallery||[],achievements:achievements||[],faqs:faqs||[],settings:settings||[]});
  }
  if(req.method!=='POST')return send(res,405,{error:'Method not allowed'});
  const {action}=req.body||{};
  if(action==='update_setting'){const key=clean(req.body.key,100),value=clean(req.body.value,2000);if(!key)return send(res,400,{error:'Setting key is required.'});const {data,error}=await db.from('site_settings').upsert({key,value,updated_at:new Date().toISOString()},{onConflict:'key'}).select().single();if(error)throw error;return send(res,200,{setting:data});}
  if(action==='upload_photo'){
    const fileName=clean(req.body.file_name,180).replace(/[^a-zA-Z0-9._-]/g,'-');const mime=clean(req.body.mime_type,100);const dataUrl=String(req.body.data_url||'');
    if(!fileName||!mime||!dataUrl.startsWith('data:image/'))return send(res,400,{error:'A valid image is required.'});
    const base64=dataUrl.split(',')[1]||'';const buffer=Buffer.from(base64,'base64');if(buffer.length>4*1024*1024)return send(res,413,{error:'Image is too large. Please upload an image under 4 MB.'});
    const path=`admin/${Date.now()}-${fileName}`;const {error:uErr}=await db.storage.from('summit-trails-media').upload(path,buffer,{contentType:mime,upsert:false});if(uErr)throw uErr;
    const {data:pub}=db.storage.from('summit-trails-media').getPublicUrl(path);return send(res,201,{url:pub.publicUrl,path});
  }

  if(action==='create_adventure'||action==='update_adventure'){
    const payload={...(req.body.adventure||{})};
    if(!payload.title||!payload.mountain_name||!payload.route||!payload.description||!payload.itinerary) return send(res,400,{error:'Title, mountain, route, description and itinerary are required.'});
    payload.currency=payload.currency||'KES'; payload.active=payload.active===true; payload.featured=payload.featured===true;
    if(payload.adult_price!==undefined) payload.price_per_person=Number(payload.adult_price);
    if(action==='create_adventure'){const {data,error}=await db.from('adventures').insert(payload).select('*, departures(*)').single();if(error)throw error;return send(res,201,{adventure:data});}
    const id=Number(req.body.adventure_id); delete payload.id; delete payload.created_at; delete payload.updated_at; payload.updated_at=new Date().toISOString();
    const {data,error}=await db.from('adventures').update(payload).eq('id',id).select('*, departures(*)').single();if(error)throw error;return send(res,200,{adventure:data});
  }
  if(action==='deactivate_adventure'){const id=Number(req.body.adventure_id);const {data,error}=await db.from('adventures').update({active:false,updated_at:new Date().toISOString()}).eq('id',id).select().single();if(error)throw error;return send(res,200,{adventure:data});}
  if(action==='delete_adventure'){const id=Number(req.body.adventure_id);const {count,error}=await db.from('bookings').select('id',{count:'exact',head:true}).eq('adventure_id',id);if(error)throw error;if((count||0)>0)return send(res,409,{error:'This adventure has bookings. Deactivate it instead of deleting it.'});const {error:e}=await db.from('adventures').delete().eq('id',id);if(e)throw e;return send(res,200,{ok:true});}
  if(action==='create_departure'||action==='update_departure'){
    const payload=req.body.departure||{}; if(Number(payload.available_slots)<0||!payload.start_date||!payload.end_date)return send(res,400,{error:'Valid dates and capacity are required.'});
    if(action==='create_departure'){const {data,error}=await db.from('departures').insert(payload).select().single();if(error)throw error;return send(res,201,{departure:data});}
    const {data,error}=await db.from('departures').update(payload).eq('id',Number(req.body.departure_id)).select().single();if(error)throw error;return send(res,200,{departure:data});
  }

  if(action==='approve_booking'||action==='cancel_booking'||action==='update_booking_status'){
    const bookingId=Number(req.body.booking_id); const current=await bookingContext(db,bookingId);
    let nextStatus=action==='approve_booking'?'confirmed':action==='cancel_booking'?'cancelled':clean(req.body.status,30);
    if(!['pending','confirmed','paid','cancelled','completed'].includes(nextStatus))return send(res,400,{error:'Invalid booking status.'});
    if(current.status==='cancelled'&&nextStatus!=='cancelled')return send(res,409,{error:'Cancelled bookings must not be reopened automatically.'});
    const {data:booking,error}=await db.from('bookings').update({status:nextStatus,admin_note:clean(req.body.note||current.admin_note,2000)}).eq('id',bookingId).select().single();if(error)throw error;
    if(nextStatus==='cancelled'&&current.status!=='cancelled'){
      const {data:dep}=await db.from('departures').select('available_slots').eq('id',current.departure_id).single();
      if(dep)await db.from('departures').update({available_slots:Number(dep.available_slots)+Number(current.number_of_trekkers)}).eq('id',current.departure_id);
    }
    if(nextStatus!=='cancelled'&&current.status==='cancelled')return send(res,409,{error:'Cancelled booking capacity is not restored automatically.'});
    await db.from('notifications').insert({user_id:current.user_id,booking_id:bookingId,type:'booking_status',title:'Booking status updated',message:`Your Summit Trails booking ${booking.booking_reference} is now ${nextStatus}.`});
    if(current.profiles?.full_name&&current.profiles?.id){
      if(nextStatus==='confirmed') await sendEmail({to:current.customer_email||req.body.email,subject:'Your Summit Trails Booking is Confirmed',html:templates.bookingConfirmed({name:current.profiles.full_name,booking:{...current, ...booking},adventure:current.adventures,departure:current.departures})}).catch(()=>{});
      else await sendEmail({to:current.customer_email||req.body.email,subject:`Summit Trails Booking Status — ${nextStatus}`,html:templates.statusUpdate({name:current.profiles.full_name,booking, status:nextStatus,note:req.body.note})}).catch(()=>{});
    }
    return send(res,200,{booking});
  }

  if(action==='send_payment_reminder'){
    const bookingId=Number(req.body.booking_id);const b=await bookingContext(db,bookingId);const balance=Math.max(0,Number(b.total_price)-Number(b.amount_paid));if(balance<=0)return send(res,409,{error:'This booking has no outstanding balance.'});
    const result=await sendEmail({to:b.customer_email,subject:'Payment Reminder — Summit Trails',html:templates.paymentReminder({name:b.profiles?.full_name||'Summit Trails customer',booking:b})});
    await db.from('notifications').insert({user_id:b.user_id,booking_id:b.id,type:'payment_reminder',title:'Payment reminder sent',message:`A reminder was sent for the outstanding balance of KSh ${balance.toLocaleString()}.`});
    return send(res,result.sent?200:503,{sent:result.sent,error:result.sent?undefined:'Email provider is not configured.'});
  }
  if(action==='log_payment'){
    const bookingId=Number(req.body.booking_id), amount=Number(req.body.amount); if(!bookingId||!amount||amount<=0)return send(res,400,{error:'Invalid payment.'});
    const b=await bookingContext(db,bookingId); if(b.status==='cancelled')return send(res,409,{error:'Cannot record payment against a cancelled booking.'});
    const remaining=Math.max(0,Number(b.total_price)-Number(b.amount_paid)); if(amount>remaining)return send(res,409,{error:`Payment exceeds the outstanding balance of KSh ${remaining.toLocaleString()}.`});
    const {data:p,error:pErr}=await db.from('payments').insert({booking_id:bookingId,amount,method:clean(req.body.method,80),transaction_reference:clean(req.body.transaction_reference,120),status:'verified'}).select().single();if(pErr)throw pErr;
    const paid=Number(b.amount_paid)+amount,status=paid>=Number(b.total_price)?'paid':(b.status==='pending'?'pending':'confirmed');
    const {data:updated,error:uErr}=await db.from('bookings').update({amount_paid:paid,status,admin_note:`Verified payment logged: KSh ${amount.toLocaleString()} via ${clean(req.body.method,80)} (${clean(req.body.transaction_reference,120)})`}).eq('id',bookingId).select().single();if(uErr)throw uErr;
    await db.from('notifications').insert({user_id:b.user_id,booking_id:bookingId,type:'payment',title:'Payment received',message:`KSh ${amount.toLocaleString()} has been recorded against booking ${updated.booking_reference}.`});
    if(b.profiles?.full_name)await sendEmail({to:b.customer_email,subject:'Payment Received — Summit Trails',html:templates.paymentReceived({name:b.profiles.full_name,booking:updated,payment:p})}).catch(()=>{});
    return send(res,200,{payment:p,booking:updated});
  }

  if(action==='reply_message'){
    const messageId=Number(req.body.message_id), body=clean(req.body.reply,5000);if(!messageId||!body)return send(res,400,{error:'Message and reply are required.'});
    const {data:thread,error:tErr}=await db.from('contact_messages').select('*, message_replies(*)').eq('id',messageId).single();if(tErr)throw tErr;
    const adminName=clean(req.body.sender_name||'Summit Trails',120);
    const {data:reply,error:rErr}=await db.from('message_replies').insert({contact_message_id:messageId,sender_type:'admin',sender_name:adminName,body,email_status:'not_sent'}).select().single();if(rErr)throw rErr;
    let emailStatus='not_sent';
    try { const result=await sendEmail({to:thread.email,subject:`Re: ${thread.subject} — Summit Trails`,html:templates.customerMessageReply({name:thread.full_name,reply:body,conversationId:thread.conversation_id}),replyTo:process.env.ADMIN_NOTIFICATION_EMAIL}); emailStatus=result.sent?'sent':'not_sent'; } catch(e){ emailStatus='failed'; }
    await db.from('message_replies').update({email_status:emailStatus}).eq('id',reply.id);
    await db.from('contact_messages').update({status:'replied',last_replied_at:new Date().toISOString(),updated_at:new Date().toISOString()}).eq('id',messageId);
    return send(res,emailStatus==='sent'?200:503,{reply:{...reply,email_status:emailStatus},error:emailStatus==='sent'?undefined:'Reply saved, but the email provider is not configured or rejected the message.'});
  }
  if(action==='message_status'){const id=Number(req.body.message_id),status=clean(req.body.status,30);if(!['new','read','replied','resolved','archived'].includes(status))return send(res,400,{error:'Invalid message status.'});const {data,error}=await db.from('contact_messages').update({status,updated_at:new Date().toISOString()}).eq('id',id).select().single();if(error)throw error;return send(res,200,{message:data});}
  if(action==='delete_message'){const {error}=await db.from('contact_messages').delete().eq('id',Number(req.body.message_id));if(error)throw error;return send(res,200,{ok:true});}

  const contentMap={
    destination:{table:'destinations',required:['name','slug','description']},
    safari:{table:'safari_packages',required:['name','slug','destination','duration_label','description']},
    gallery:{table:'gallery_images',required:['image_url']},
    achievement:{table:'achievements',required:['title','description']},
    faq:{table:'faqs',required:['question','answer']}
  };
  const kind=action?.startsWith('create_')?action.slice(7):action?.startsWith('update_')?action.slice(7):action?.startsWith('delete_')?action.slice(7):action?.startsWith('deactivate_')?action.slice(10):null;
  if(contentMap[kind]){
    const cfg=contentMap[kind], payload={...(req.body.item||{})};
    if(kind==='destination' || kind==='safari' || kind==='gallery' || kind==='achievement' || kind==='faq'){
      if(kind==='destination') payload.highlights=list(payload.highlights);
      if(kind==='safari') payload.highlights=list(payload.highlights);
      if(!action.startsWith('delete_')&&!action.startsWith('deactivate_')){for(const key of cfg.required){if(!payload[key])return send(res,400,{error:`${key} is required.`});}}
      if(action.startsWith('delete_')){const {error}=await db.from(cfg.table).delete().eq('id',Number(req.body.id));if(error)throw error;return send(res,200,{ok:true});}
      if(action.startsWith('deactivate_')){const {data,error}=await db.from(cfg.table).update({active:false,updated_at:new Date().toISOString()}).eq('id',Number(req.body.id)).select().single();if(error)throw error;return send(res,200,{item:data});}
      if(action.startsWith('create_')){const {data,error}=await db.from(cfg.table).insert(payload).select().single();if(error)throw error;return send(res,201,{item:data});}
      delete payload.id;delete payload.created_at;payload.updated_at=new Date().toISOString();const {data,error}=await db.from(cfg.table).update(payload).eq('id',Number(req.body.id)).select().single();if(error)throw error;return send(res,200,{item:data});
    }
  }
  if(action==='create_safari_departure'){const {data,error}=await db.from('safari_departures').insert(req.body.item||{}).select().single();if(error)throw error;return send(res,201,{item:data});}
  if(action==='update_safari_departure'){const {data,error}=await db.from('safari_departures').update(req.body.item||{}).eq('id',Number(req.body.id)).select().single();if(error)throw error;return send(res,200,{item:data});}
  if(action==='delete_safari_departure'){const {error}=await db.from('safari_departures').delete().eq('id',Number(req.body.id));if(error)throw error;return send(res,200,{ok:true});}

  return send(res,400,{error:'Unknown admin action'});
 }catch(e){send(res,e.statusCode||500,{error:e.message});}
};
