const { adminClient, send } = require('../_lib/supabase');
const { sendEmail, templates } = require('../_lib/email');
module.exports=async(req,res)=>{
 try{
  if(req.method!=='POST')return send(res,405,{error:'Method not allowed'});
  const body=req.body||{}; const cb=body.Body&&body.Body.stkCallback; if(!cb)return send(res,400,{ResultCode:1,ResultDesc:'Invalid callback'});
  const db=adminClient(); const items=cb.CallbackMetadata?.Item||[]; const get=(name)=>items.find(x=>x.Name===name)?.Value; const receipt=get('MpesaReceiptNumber');
  const {data:p,error:pErr}=await db.from('payments').select('*').eq('checkout_request_id',cb.CheckoutRequestID).single(); if(pErr)throw pErr;
  if(p.status==='verified')return send(res,200,{ResultCode:0,ResultDesc:'Already processed'});
  const {data:b,error:bErr}=await db.from('bookings').select('*, profiles(full_name,phone_number), adventures(*), departures(*)').eq('id',p.booking_id).single(); if(bErr)throw bErr;
  const {data:authUser}=await db.auth.admin.getUserById(b.user_id); const customerEmail=authUser?.user?.email||'';
  if(String(cb.ResultCode)==='0'){
   const paid=Number(b.amount_paid)+Number(p.amount); const status=paid>=Number(b.total_price)?'paid':'confirmed';
   await db.from('payments').update({status:'verified',transaction_reference:receipt,result_code:String(cb.ResultCode),result_description:cb.ResultDesc}).eq('id',p.id);
   const {data:updated}=await db.from('bookings').update({amount_paid:paid,status,admin_note:`M-PESA Express payment of KSh ${p.amount} received successfully. Ref: ${receipt||'pending receipt'}.`}).eq('id',b.id).select().single();
   await db.from('notifications').insert({user_id:b.user_id,booking_id:b.id,type:'payment',title:'Payment received',message:`KSh ${Number(p.amount).toLocaleString()} has been verified for booking ${b.booking_reference}.`});
   if(customerEmail)await sendEmail({to:customerEmail,subject:'Payment Received — Summit Trails',html:templates.paymentReceived({name:b.profiles?.full_name||'Summit Trails customer',booking:updated||b,payment:{...p,transaction_reference:receipt,created_at:new Date().toISOString()}})}).catch(()=>{});
  }else{
   await db.from('payments').update({status:'failed',result_code:String(cb.ResultCode),result_description:cb.ResultDesc}).eq('id',p.id);
  }
  send(res,200,{ResultCode:0,ResultDesc:'Accepted'});
 }catch(e){send(res,200,{ResultCode:0,ResultDesc:'Accepted'});}
};
