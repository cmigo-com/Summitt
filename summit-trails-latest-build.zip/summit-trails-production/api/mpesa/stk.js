const { requireUser, send } = require('../_lib/supabase');

function mpesaBase(){ return process.env.MPESA_ENV==='production' ? 'https://api.safaricom.co.ke' : 'https://sandbox.safaricom.co.ke'; }
function normalizePhone(phone){ let p=String(phone||'').replace(/\D/g,''); if(p.startsWith('0'))p='254'+p.slice(1); if(p.startsWith('7'))p='254'+p; return p; }
function stamp(){ const d=new Date(); const parts=[d.getUTCFullYear(),String(d.getUTCMonth()+1).padStart(2,'0'),String(d.getUTCDate()).padStart(2,'0'),String(d.getUTCHours()).padStart(2,'0'),String(d.getUTCMinutes()).padStart(2,'0'),String(d.getUTCSeconds()).padStart(2,'0')]; return parts.join(''); }
async function token(){ const basic=Buffer.from(`${process.env.MPESA_CONSUMER_KEY}:${process.env.MPESA_CONSUMER_SECRET}`).toString('base64'); const r=await fetch(`${mpesaBase()}/oauth/v1/generate?grant_type=client_credentials`,{headers:{Authorization:`Basic ${basic}`}}); const j=await r.json(); if(!r.ok||!j.access_token)throw new Error(j.errorMessage||'Unable to obtain M-PESA access token'); return j.access_token; }
module.exports=async(req,res)=>{
 try{
  if(req.method!=='POST')return send(res,405,{error:'Method not allowed'});
  const {user,db}=await requireUser(req); const {booking_id,amount,phone}=req.body||{}; const n=Math.floor(Number(amount));
  if(!booking_id||!n||n<1) return send(res,400,{error:'Invalid booking or amount'});
  const {data:b,error:bErr}=await db.from('bookings').select('*, profiles!inner(id)').eq('id',booking_id).eq('user_id',user.id).single(); if(bErr)throw bErr;
  const outstanding=Number(b.total_price)-Number(b.amount_paid); if(n>outstanding)return send(res,400,{error:`Payment cannot exceed the outstanding balance of KSh ${outstanding.toLocaleString()}.`});
  const access=await token(); const timestamp=stamp(); const password=Buffer.from(`${process.env.MPESA_SHORTCODE}${process.env.MPESA_PASSKEY}${timestamp}`).toString('base64'); const msisdn=normalizePhone(phone||user.phone||b.phone_number);
  if(!/^2547\d{8}$/.test(msisdn))return send(res,400,{error:'Enter a valid Kenyan M-PESA phone number.'});
  const payload={BusinessShortCode:process.env.MPESA_SHORTCODE,Password:password,Timestamp:timestamp,TransactionType:'CustomerPayBillOnline',Amount:n,PartyA:msisdn,PartyB:process.env.MPESA_SHORTCODE,PhoneNumber:msisdn,CallBackURL:process.env.MPESA_CALLBACK_URL,AccountReference:process.env.MPESA_ACCOUNT_REFERENCE||'SUMMITTRAILS',TransactionDesc:process.env.MPESA_TRANSACTION_DESC||'Summit Trails booking payment'};
  const r=await fetch(`${mpesaBase()}/mpesa/stkpush/v1/processrequest`,{method:'POST',headers:{Authorization:`Bearer ${access}`,'Content-Type':'application/json'},body:JSON.stringify(payload)}); const j=await r.json(); if(!r.ok||j.ResponseCode!=='0')throw new Error(j.errorMessage||j.errorDescription||'M-PESA STK Push failed');
  const {data:p,error:pErr}=await db.from('payments').insert({booking_id,amount:n,method:'M-PESA Express',merchant_request_id:j.MerchantRequestID,checkout_request_id:j.CheckoutRequestID,status:'pending'}).select().single(); if(pErr)throw pErr;
  send(res,200,{message:`STK Push sent to ${msisdn}. Enter your M-PESA PIN on your phone.`,checkoutRequestId:j.CheckoutRequestID,paymentId:p.id});
 }catch(e){send(res,e.statusCode||500,{error:e.message});}
};
