const { requireUser, send } = require('../_lib/supabase');
module.exports=async(req,res)=>{
 try{
  if(req.method!=='POST') return send(res,405,{error:'Method not allowed'});
  const {user,db}=await requireUser(req); const {booking_id,full_name,emergency_phone,dietary,medical}=req.body||{};
  if(!booking_id||!full_name||!emergency_phone) return send(res,400,{error:'Full name and emergency phone are required'});
  const {data:b,error:bErr}=await db.from('bookings').select('id,number_of_trekkers').eq('id',booking_id).eq('user_id',user.id).single(); if(bErr) throw bErr;
  const {count,error:cErr}=await db.from('travelers').select('*',{count:'exact',head:true}).eq('booking_id',booking_id); if(cErr) throw cErr;
  if(count>=b.number_of_trekkers) return send(res,409,{error:'All trekker profiles for this booking are already registered.'});
  const {data,error}=await db.from('travelers').insert({booking_id,full_name,emergency_phone,dietary,medical}).select().single(); if(error) throw error;
  send(res,201,{traveler:data});
 }catch(e){send(res,e.statusCode||500,{error:e.message});}
};
