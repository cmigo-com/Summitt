-- Summit Trails contact form: store the sender phone number.
alter table if exists public.contact_messages
  add column if not exists phone text;
